#lang racket

(define (empty-k) `(empty-k))
(define (fib-inner-k v^ k^) `(fib-inner-k ,v^ ,k^))
(define (fib-outer-k n^ k^) `(fib-outer-k ,n^ ,k^))

(define (apply-k k v)
  (match k
    [`(empty-k) v]
    [`(fib-inner-k ,v^ ,k^)
     (apply-k k^ (+ v^ v))]
    [`(fib-outer-k ,n^ ,k^)
     (fib-cps (sub1 (sub1 n^))
              (fib-inner-k v k^))]
    ;; (else (k v))
    ))

(define (fib-cps n k)
  (if (< n 2)
      (apply-k k n)
      (fib-cps (sub1 n) (fib-outer-k n k))))

(fib-cps 5 (empty-k))
