#lang racket
(require "parenthec.rkt")

(define-union kt
  (empty-k)
  (fib-inner-k v^ k^)
  (fib-outer-k n^ k^))

(define (apply-k k v)
  (union-case k kt
    [(empty-k) v]
    [(fib-inner-k v^ k^)
     (apply-k k^ (+ v^ v))]
    [(fib-outer-k n^ k^)
     (fib-cps (sub1 (sub1 n^))
              (kt_fib-inner-k v k^))]))

(define (fib-cps n k)
  (if (< n 2)
      (apply-k k n)
      (fib-cps (sub1 n) (kt_fib-outer-k n k))))

(fib-cps 5 (kt_empty-k))
