void *n, *k, *v;

void (*pc)();

struct kt;
typedef struct kt kt;
struct kt {
  enum {
    _emptyr__m__k_kt,
    _fibr__m__innerr__m__k_kt,
    _fibr__m__outerr__m__k_kt
  } tag;
  union {
    struct { void *_j; } _emptyr__m__k;
    struct { void *_vr__ex__; void *_kr__ex__; } _fibr__m__innerr__m__k;
    struct { void *_nr__ex__; void *_kr__ex__; } _fibr__m__outerr__m__k;
  } u;
};

void *ktr_emptyr__m__k(void *j);
void *ktr_fibr__m__innerr__m__k(void *vr__ex__, void *kr__ex__);
void *ktr_fibr__m__outerr__m__k(void *nr__ex__, void *kr__ex__);

void applyr__m__k();
void fibr__m__cps();
int main();
int mount_tram();

struct _trstr;
typedef struct _trstr _trstr;
struct _trstr {
  jmp_buf *jmpbuf;
  int value;
};

