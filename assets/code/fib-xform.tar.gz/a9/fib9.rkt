#lang racket
(require "parenthec.rkt")
(define-registers n k v)
(define-program-counter pc)

(define-union kt
  (empty-k j)
  (fib-inner-k v^ k^)
  (fib-outer-k n^ k^))

(define-label apply-k  ;k v
  (union-case k kt
    [(empty-k j) (dismount-trampoline j)]
    [(fib-inner-k v^ k^)
     (begin
       (set! v (+ v^ v))
       (set! k k^)             
       (set! pc apply-k))]  ; k v
    [(fib-outer-k n^ k^)
     (begin
       (set! n (sub1 (sub1 n^)))
       (set! k (kt_fib-inner-k v k^))
       (set! pc fib-cps))]))  ;n k

(define-label fib-cps  ;n k
  (if (< n 2)
      (begin
        (set! v n)
        (set! pc apply-k))  ;k v
      (begin
        (set! k (kt_fib-outer-k n k))
        (set! n (sub1 n))
        (set! pc fib-cps))))  ; n k

(define-label main
 (begin
   (set! n 5)
   (set! pc fib-cps)
   (mount-trampoline kt_empty-k k pc)
   (printf "~s\n" v))) ;n k
