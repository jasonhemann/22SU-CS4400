#lang racket

(define (fib-cps n k)
  (if (< n 2)
      (k n)
      (fib-cps (sub1 n)
        (lambda (v)
          (fib-cps (sub1 (sub1 n))
            (lambda (w) 
              (k (+ v w))))))))

(fib-cps 5 (lambda (v) v))
