#include <setjmp.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "fib.h"

void *ktr_emptyr__m__k(void *j) {
kt* _data = (kt*)malloc(sizeof(kt));
if(!_data) {
  fprintf(stderr, "Out of memory\n");
  exit(1);
}
  _data->tag = _emptyr__m__k_kt;
  _data->u._emptyr__m__k._j = j;
  return (void *)_data;
}

void *ktr_fibr__m__innerr__m__k(void *vr__ex__, void *kr__ex__) {
kt* _data = (kt*)malloc(sizeof(kt));
if(!_data) {
  fprintf(stderr, "Out of memory\n");
  exit(1);
}
  _data->tag = _fibr__m__innerr__m__k_kt;
  _data->u._fibr__m__innerr__m__k._vr__ex__ = vr__ex__;
  _data->u._fibr__m__innerr__m__k._kr__ex__ = kr__ex__;
  return (void *)_data;
}

void *ktr_fibr__m__outerr__m__k(void *nr__ex__, void *kr__ex__) {
kt* _data = (kt*)malloc(sizeof(kt));
if(!_data) {
  fprintf(stderr, "Out of memory\n");
  exit(1);
}
  _data->tag = _fibr__m__outerr__m__k_kt;
  _data->u._fibr__m__outerr__m__k._nr__ex__ = nr__ex__;
  _data->u._fibr__m__outerr__m__k._kr__ex__ = kr__ex__;
  return (void *)_data;
}

int main()
{
n = (void *)(void *)5;
pc = &fibr__m__cps;
mount_tram();
printf("%d\n", (int)v);}

void fibr__m__cps()
{
if((n < (void *)2)) {
  v = (void *)n;
pc = &applyr__m__k;

} else {
  k = (void *)ktr_fibr__m__outerr__m__k(n,k);
n = (void *)(void *)((int)n - 1);
pc = &fibr__m__cps;

}
}

void applyr__m__k()
{
kt* _c = (kt*)k;
switch (_c->tag) {
case _emptyr__m__k_kt: {
void *j = _c->u._emptyr__m__k._j;
_trstr *trstr = (_trstr *)j;
longjmp(*trstr->jmpbuf, 1);
break; }
case _fibr__m__innerr__m__k_kt: {
void *vr__ex__ = _c->u._fibr__m__innerr__m__k._vr__ex__;
void *kr__ex__ = _c->u._fibr__m__innerr__m__k._kr__ex__;
v = (void *)(void *)((int)vr__ex__ + (int)v);
k = (void *)kr__ex__;
pc = &applyr__m__k;
break; }
case _fibr__m__outerr__m__k_kt: {
void *nr__ex__ = _c->u._fibr__m__outerr__m__k._nr__ex__;
void *kr__ex__ = _c->u._fibr__m__outerr__m__k._kr__ex__;
n = (void *)(void *)((int)(void *)((int)nr__ex__ - 1) - 1);
k = (void *)ktr_fibr__m__innerr__m__k(v,kr__ex__);
pc = &fibr__m__cps;
break; }
}
}

int mount_tram ()
{
srand (time (NULL));
jmp_buf jb;
_trstr trstr;
void *dismount;
int _status = setjmp(jb);
trstr.jmpbuf = &jb;
dismount = &trstr;
if(!_status) {
k= (void *)ktr_emptyr__m__k(dismount);
for(;;) {
pc();
}
}
return 0;
}
