#lang racket

(define (apply-k k v)
  (k v))
(define (empty-k)
  (lambda (v) v))

(define (fib-inner-k v k)  
  (lambda (w) 
    (apply-k k (+ v w))))

(define (fib-outer-k n k)
  (lambda (v)
    (fib-cps (sub1 (sub1 n))
             (fib-inner-k v k))))

(define (fib-cps n k)
  (if (< n 2)
      (apply-k k n)
      (fib-cps (sub1 n) (fib-outer-k n k))))

(fib-cps 5 (empty-k))
