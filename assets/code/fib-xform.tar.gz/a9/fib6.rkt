#lang racket
(require "parenthec.rkt")

(define-union kt
  (empty-k)
  (fib-inner-k v^ k^)
  (fib-outer-k n^ k^))

(define (apply-k k v)
  (union-case k kt
    [(empty-k) 
     (let* ()
       v)]
    [(fib-inner-k v^ k^)
     (let* ((v (+ v^ v))
            (k k^))
      (apply-k k v))]
    [(fib-outer-k n^ k^)
     (let* ((n (sub1 (sub1 n^)))
            (k (kt_fib-inner-k v k^)))
      (fib-cps n k))]))

(define (fib-cps n k)
  (if (< n 2)
      (let* ((v n))
        (apply-k k v))
      (let* ((k (kt_fib-outer-k n k))
             (n (sub1 n)))
       (fib-cps n k))))

(let* ((n 5)
       (k (kt_empty-k)))
  (fib-cps n k))
